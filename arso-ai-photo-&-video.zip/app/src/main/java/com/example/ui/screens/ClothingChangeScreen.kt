package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ArsoViewModel
import com.example.ui.DrawableResolver

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClothingChangeScreen(
    viewModel: ArsoViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToDetail: () -> Unit
) {
    val isProcessing by viewModel.isProcessing.collectAsState()
    val progress by viewModel.processingProgress.collectAsState()
    val logText by viewModel.processingLog.collectAsState()

    var projectTitle by remember { mutableStateOf("") }
    var clothingPrompt by remember { mutableStateOf("") }

    val personPresets = listOf(
        viewModel.sampleImageMan to "Handsome Man",
        viewModel.sampleImageWoman to "Elegant Woman"
    )

    var selectedPerson by remember { mutableStateOf(personPresets[0].first) }

    // Quick prompt template tags helper
    val templates = listOf(
        "Futuristic Stainless Steel Armor",
        "Royal Crimson Velvet Tuxedo",
        "Ethereal Emerald Silk Evening Gown",
        "Steampunk Leather Mechanics Vest"
    )

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Clothing Refit", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("clothing_change_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (isProcessing) {
            AIProcessingView(progress = progress, logText = logText)
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(scrollState)
                    .testTag("clothing_main_scroll"),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Live preview card representation
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.Gray)
                        .testTag("clothing_preview_box")
                ) {
                    Image(
                        painter = painterResource(id = DrawableResolver.resolve(selectedPerson)),
                        contentDescription = "Base avatar",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Overlay tinting representation based on outfit
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.15f))
                    )

                    // Sparkle status Badge
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(14.dp)
                            .background(
                                MaterialTheme.colorScheme.primaryContainer,
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(12.dp),
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                "Segment Overlay Mask Active",
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Project Title Input
                Text(
                    text = "Project Name",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                OutlinedTextField(
                    value = projectTitle,
                    onValueChange = { projectTitle = it },
                    placeholder = { Text("E.g., Space Suit Refit") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("clothing_title_input"),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )

                // Choose Portrait base
                Text(
                    text = "Select Person Portrait",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    personPresets.forEach { (img, label) ->
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { selectedPerson = img },
                            colors = CardDefaults.cardColors(
                                containerColor = if (selectedPerson == img) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = BorderStroke(
                                width = if (selectedPerson == img) 2.dp else 0.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(id = DrawableResolver.resolve(img)),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                                Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            }
                        }
                    }
                }

                // Custom Text Description Input
                Text(
                    text = "Describe Desired Clothing",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                OutlinedTextField(
                    value = clothingPrompt,
                    onValueChange = { clothingPrompt = it },
                    placeholder = { Text("E.g., A formal modern slate blazer with neon cyan highlights on lapels.") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .testTag("clothing_prompt_input"),
                    shape = RoundedCornerShape(16.dp),
                    maxLines = 4
                )

                // Quick Templates chips list
                Text(
                    text = "Instant Wardrobe Prompts",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // split into two lines or simple row wrap using column for premium look
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        templates.chunked(2).forEach { chunk ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                chunk.forEach { prompt ->
                                    val isSelected = clothingPrompt == prompt
                                    InputChip(
                                        selected = isSelected,
                                        onClick = { clothingPrompt = prompt },
                                        label = { Text(prompt, fontSize = 11.sp, maxLines = 1) },
                                        avatar = {
                                            if (isSelected) {
                                                Icon(
                                                    Icons.Filled.Check,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        viewModel.runClothingChange(
                            title = projectTitle,
                            personImage = selectedPerson,
                            clothingDescription = clothingPrompt.ifBlank { "Futuristic Cyberwear Suit" }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("run_clothing_button"),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Synthesize Wardrobe", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
