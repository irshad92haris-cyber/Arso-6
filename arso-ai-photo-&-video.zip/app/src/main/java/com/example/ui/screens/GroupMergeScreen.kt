package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ArsoViewModel
import com.example.ui.DrawableResolver

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupMergeScreen(
    viewModel: ArsoViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToDetail: () -> Unit
) {
    val isProcessing by viewModel.isProcessing.collectAsState()
    val progress by viewModel.processingProgress.collectAsState()
    val logText by viewModel.processingLog.collectAsState()

    var projectTitle by remember { mutableStateOf("") }
    var customBgPrompt by remember { mutableStateOf("") }

    val portraitOptions = listOf(
        viewModel.sampleImageMan to "Handsome Man",
        viewModel.sampleImageWoman to "Elegant Woman",
        viewModel.sampleImageGroup to "Corporate Friend Group"
    )

    // User selected portraits (Up to 3 slots)
    var slot1 by remember { mutableStateOf<String?>(viewModel.sampleImageMan) }
    var slot2 by remember { mutableStateOf<String?>(viewModel.sampleImageWoman) }
    var slot3 by remember { mutableStateOf<String?>(null) }

    val bgPresets = listOf(
        "Golden Beach Sunset",
        "Cyberpunk Studio Loft",
        "Minimalist Slate Gray Studio",
        "Retro Glow Arcade"
    )
    var selectedBgPreset by remember { mutableStateOf(bgPresets[0]) }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Group Merge", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("group_merge_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (isProcessing) {
            AIProcessingView(progress = progress, logText = logText)
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(scrollState)
                    .testTag("group_merge_main_scroll"),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Interactive background and cutout preview representation
                Text(
                    text = "Composition Placement Preview",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF1E293B))
                        .testTag("merge_studio_canvas")
                ) {
                    // Studio grid lines
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(0.3f))
                    )

                    // Arranged portraited cutouts dynamically overlaid side-by-side
                    Row(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (slot1 != null) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                            ) {
                                Image(
                                    painter = painterResource(id = DrawableResolver.resolve(slot1)),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }

                        if (slot2 != null) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, MaterialTheme.colorScheme.secondary, CircleShape)
                            ) {
                                Image(
                                    painter = painterResource(id = DrawableResolver.resolve(slot2)),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }

                        if (slot3 != null) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, MaterialTheme.colorScheme.tertiary, CircleShape)
                            ) {
                                Image(
                                    painter = painterResource(id = DrawableResolver.resolve(slot3)),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(12.dp)
                            .background(Color.Black.copy(0.7f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (customBgPrompt.isNotBlank()) "AI BG: $customBgPrompt" else "Preset: $selectedBgPreset",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }

                // Title Input
                Text(
                    text = "Project Name",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                OutlinedTextField(
                    value = projectTitle,
                    onValueChange = { projectTitle = it },
                    placeholder = { Text("E.g., Team Portrait Merge") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_title_input"),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )

                // Select Slots Config
                Text(
                    text = "Configure People (3 Slots)",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )

                // Render 3 slots selectors
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Slot 1
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Slot 1", style = MaterialTheme.typography.labelSmall)
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable {
                                    slot1 = if (slot1 == portraitOptions[0].first) portraitOptions[1].first else portraitOptions[0].first
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (slot1 != null) {
                                Image(
                                    painter = painterResource(id = DrawableResolver.resolve(slot1)),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Icon(Icons.Filled.Add, contentDescription = null)
                            }
                        }
                    }

                    // Slot 2
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Slot 2", style = MaterialTheme.typography.labelSmall)
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable {
                                    slot2 = if (slot2 == null) portraitOptions[1].first else null
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (slot2 != null) {
                                Image(
                                    painter = painterResource(id = DrawableResolver.resolve(slot2)),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Icon(Icons.Filled.Add, contentDescription = null)
                            }
                        }
                    }

                    // Slot 3
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Slot 3", style = MaterialTheme.typography.labelSmall)
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable {
                                    slot3 = if (slot3 == null) portraitOptions[2].first else null
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (slot3 != null) {
                                Image(
                                    painter = painterResource(id = DrawableResolver.resolve(slot3)),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Icon(Icons.Filled.Add, contentDescription = null)
                            }
                        }
                    }
                }

                // Preset backgrounds list selection
                Text(
                    text = "Select Studio Backdrop Preset",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    bgPresets.forEach { bg ->
                        val isSelected = selectedBgPreset == bg
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { selectedBgPreset = bg },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow
                            ),
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 0.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                RadioButton(selected = isSelected, onClick = { selectedBgPreset = bg })
                                Text(bg, fontWeight = FontWeight.Medium, modifier = Modifier.align(Alignment.CenterVertically))
                            }
                        }
                    }
                }

                // Custom BG text input (Gemini powered)
                Text(
                    text = "Or prompt a custom AI Background (Powered by Gemini)",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                OutlinedTextField(
                    value = customBgPrompt,
                    onValueChange = { customBgPrompt = it },
                    placeholder = { Text("E.g., A minimalist office lounge at sunny morning with glass windows") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_custom_bg_input"),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val finalImagesList = listOfNotNull(slot1, slot2, slot3)
                        viewModel.runGroupPhotoMerge(
                            title = projectTitle,
                            images = finalImagesList,
                            bgPreset = selectedBgPreset,
                            bgCustomText = customBgPrompt
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("run_group_merge_button"),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Synthesize Group Merge", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
