package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ArsoViewModel
import com.example.ui.DrawableResolver

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FaceSwapVideoScreen(
    viewModel: ArsoViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToDetail: () -> Unit
) {
    val isProcessing by viewModel.isProcessing.collectAsState()
    val progress by viewModel.processingProgress.collectAsState()
    val logText by viewModel.processingLog.collectAsState()

    var projectTitle by remember { mutableStateOf("") }
    
    val facePresets = listOf(
        viewModel.sampleImageMan to "Handsome Man",
        viewModel.sampleImageWoman to "Elegant Woman"
    )

    val videoPresets = listOf(
        "Sci-Fi Hologram Run" to "Retro synthwave futuristic fast chase sequence.",
        "Medieval Royal Court" to "Grand throne halls with dramatic focal lightings.",
        "Golden Runway Walk" to "Elegant high fashion spotlight studio modeling."
    )

    var selectedFace by remember { mutableStateOf(facePresets[0].first) }
    var selectedVideo by remember { mutableStateOf(videoPresets[0].first) }

    // Mock Video Playback position
    var isPlaying by remember { mutableStateOf(true) }
    var playbackPosition by remember { mutableStateOf(0.35f) }

    // Increment play position over time as helper
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                kotlinx.coroutines.delay(100)
                playbackPosition = (playbackPosition + 0.015f)
                if (playbackPosition >= 1f) {
                    playbackPosition = 0f
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Face Swap (Video)", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("swap_video_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (isProcessing) {
            AIProcessingView(progress = progress, logText = logText)
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
                    .testTag("swap_video_main_scroll"),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Interactive Video Preview
                Text(
                    text = "Cinematic Render Preview",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.Black)
                        .testTag("video_visualizer_frame"),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    // Video scene frame background
                    Image(
                        painter = painterResource(id = DrawableResolver.resolve(selectedFace)),
                        contentDescription = "Active face rendering",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Cybernetic interface overlay representing rendering lines
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Cyan.copy(alpha = 0.08f),
                                        Color.Transparent,
                                        Color.Magenta.copy(alpha = 0.12f)
                                    )
                                )
                            )
                    )

                    // Top Info Overlay
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopStart)
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Badge(containerColor = MaterialTheme.colorScheme.primary) {
                            Text(
                                "HEVC 24 FPS",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            "Frame ${ (playbackPosition * 120).toInt() } / 120",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    // Bottom Player Controls bar
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.65f))
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        // Progress bar scrubber
                        Slider(
                            value = playbackPosition,
                            onValueChange = { playbackPosition = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(16.dp),
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = Color.DarkGray
                            )
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { isPlaying = !isPlaying }) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Filled.Refresh else Icons.Filled.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = Color.White
                                )
                            }
                            Text(
                                "00:${ String.format("%02d", (playbackPosition * 10).toInt()) } : 00:10",
                                color = Color.White,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                // Title config
                Text(
                    text = "Project Name",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                OutlinedTextField(
                    value = projectTitle,
                    onValueChange = { projectTitle = it },
                    placeholder = { Text("E.g., Skyfall Face swap video") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("video_title_input"),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )

                // Face selection Config
                Text(
                    text = "Choose Face Portrait",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    facePresets.forEach { (img, label) ->
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { selectedFace = img },
                            colors = CardDefaults.cardColors(
                                containerColor = if (selectedFace == img) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = BorderStroke(
                                width = if (selectedFace == img) 2.dp else 0.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(id = DrawableResolver.resolve(img)),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                                Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            }
                        }
                    }
                }

                // Choose Video Templates
                Text(
                    text = "Select Cinematic Video Preset",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    videoPresets.forEach { (title, description) ->
                        val isSelected = selectedVideo == title
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { selectedVideo = title },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow
                            ),
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 0.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                Button(
                    onClick = {
                        viewModel.runFaceSwapVideo(
                            title = projectTitle,
                            sourceFace = selectedFace,
                            targetVideoPreset = selectedVideo
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("run_face_swap_video_button"),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Synthesize Video Face Swap", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
