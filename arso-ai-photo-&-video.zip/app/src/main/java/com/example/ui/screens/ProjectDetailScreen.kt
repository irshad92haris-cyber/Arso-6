package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ArsoProject
import com.example.ui.ArsoViewModel
import com.example.ui.DrawableResolver
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailScreen(
    viewModel: ArsoViewModel,
    onNavigateBack: () -> Unit
) {
    val project by viewModel.selectedProject.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(project?.title ?: "Project Details", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("detail_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    project?.let { proj ->
                        IconButton(onClick = { viewModel.toggleFavorite(proj) }) {
                            Icon(
                                imageVector = if (proj.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = "Toggle Favorite",
                                tint = if (proj.isFavorite) Color.Red else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = {
                            viewModel.deleteProject(proj)
                            onNavigateBack()
                        }) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Delete",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        project?.let { activeProj ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(scrollState)
                    .testTag("detail_scroll_content"),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Feature Category badge
                Badge(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Text(
                        text = activeProj.type.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold
                    )
                }

                // Render specific preview design based on project type
                when (activeProj.type) {
                    "Face Swap (Image)" -> {
                        DetailFaceSwapImageSection(activeProj, viewModel)
                    }
                    "Face Swap (Video)" -> {
                        DetailFaceSwapVideoSection(activeProj, viewModel)
                    }
                    "AI Clothing Change" -> {
                        DetailClothingSection(activeProj, viewModel)
                    }
                    "Group Photo Merge" -> {
                        DetailGroupMergeSection(activeProj, viewModel)
                    }
                }

                Divider()

                // Metadata Details Card
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            "Production Metadata",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        MetaRow("Project ID", "#${activeProj.id}")
                        val dateString = SimpleDateFormat("MMMM dd, yyyy 'at' hh:mm a", Locale.getDefault())
                            .format(Date(activeProj.timestamp))
                        MetaRow("Render Time", dateString)
                        MetaRow("Status", activeProj.status)
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        } ?: run {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("Select a project to inspect files...")
            }
        }
    }
}

@Composable
fun MetaRow(label: String, valText: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        Text(valText, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun DetailFaceSwapImageSection(project: ArsoProject, viewModel: ArsoViewModel) {
    var sliderVal by remember { mutableStateOf(0.5f) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("AI Face-Swap Playback Slider", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
                .clip(RoundedCornerShape(20.dp))
        ) {
            Image(
                painter = painterResource(id = DrawableResolver.resolve(project.inputImage2 ?: viewModel.sampleImageWoman)),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction = sliderVal)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp))
            ) {
                Image(
                    painter = painterResource(id = DrawableResolver.resolve(project.inputImage1 ?: viewModel.sampleImageMan)),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth(fraction = 1f / sliderVal)
                        .fillMaxHeight(),
                    contentScale = ContentScale.Crop
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(3.dp)
                    .align(Alignment.CenterStart)
                    .offset(x = (270 * sliderVal).dp)
                    .background(MaterialTheme.colorScheme.primary)
            )
        }

        Slider(value = sliderVal, onValueChange = { sliderVal = it })
    }
}

@Composable
fun DetailFaceSwapVideoSection(project: ArsoProject, viewModel: ArsoViewModel) {
    var playPercent by remember { mutableStateOf(0.3f) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(100)
            playPercent = (playPercent + 0.02f)
            if (playPercent >= 1f) {
                playPercent = 0f
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Synthesized Video Stream", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.BottomCenter
        ) {
            Image(
                painter = painterResource(id = DrawableResolver.resolve(project.inputImage1 ?: viewModel.sampleImageMan)),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(0.7f))
                    .padding(8.dp)
            ) {
                LinearProgressIndicator(
                    progress = { playPercent },
                    modifier = Modifier.fillMaxWidth().height(4.dp),
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("ACTIVE VIDEO SWAP", style = MaterialTheme.typography.labelSmall, color = Color.White)
                    Text(project.prompt ?: "Sci-Fi Preset", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
fun DetailClothingSection(project: ArsoProject, viewModel: ArsoViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Garment Mask Render", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .clip(RoundedCornerShape(20.dp))
        ) {
            Image(
                painter = painterResource(id = DrawableResolver.resolve(project.inputImage1 ?: viewModel.sampleImageMan)),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Sparkle overlay representing diffusion overlay mask
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(20.dp))
            )
        }

        ElevatedCard(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.elevatedCardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHighest
            )
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Gemini Diffusion Styling Advisory", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Text(
                    text = project.prompt ?: "Synthesizing customized wardrobe garment mask specifications.",
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun DetailGroupMergeSection(project: ArsoProject, viewModel: ArsoViewModel) {
    val description = project.prompt ?: "Studio Preset Backdrop"

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("AI Combined Output Display", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.BottomCenter
        ) {
            // Background preset identifier
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color(0xFF311B92).copy(alpha = 0.5f), Color(0xFF0F172A))
                        )
                    )
            )

            // Overlapped segmented circles representation
            Row(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy((-16).dp) // side overlapping
            ) {
                if (project.inputImage1 != null) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .border(3.dp, Color.White, CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = DrawableResolver.resolve(project.inputImage1)),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                if (project.inputImage2 != null) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .border(3.dp, Color.White, CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = DrawableResolver.resolve(project.inputImage2)),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                if (project.inputImage3 != null) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .border(3.dp, Color.White, CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = DrawableResolver.resolve(project.inputImage3)),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(0.6f))
                    .padding(8.dp)
            ) {
                Text(
                    text = "Merged Cutouts onto: $description",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
        }
    }
}
